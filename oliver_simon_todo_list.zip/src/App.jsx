import { useState } from 'react'
import './App.css'
import ToDoDisplay from './components/ToDoDisplay'
import ToDoForm from './components/ToDoForm'

function App() {

  const [toDo, setToDo] = useState([]);
  const [statuss, setStatus] = useState(false)
  const updateToDo = (newToDo) => {
    setToDo((prevToDo) => [...prevToDo, newToDo])
  }


  return (
    <>
  <ToDoForm updateToDo = {updateToDo}/>
  <ToDoDisplay toDo = {toDo}/>
    </>
  )
}

export default App
