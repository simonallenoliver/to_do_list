import React, { useState } from 'react'

const ToDoForm = (props) => {

    const {updateToDo} = props;
    const [toDo, setToDo] = useState("");
    const [statuss, setStatus] = useState(false);

    const submitHandler = (e) => {
        e.preventDefault();
        // setBoxes((prevBoxes) => [...prevBoxes, color]) ---this was moved to app.jsx for lifted state
        updateToDo(
            {
                toDo: toDo,
                statuss: statuss
            }
        )
        // double binding
        setToDo("");

        
    }

  return (
    <div>
        <form onSubmit={submitHandler}>
                    <div className='inputContainer'>
                        <label htmlFor="toDo">Enter a toDo: </label>
                        <input
                            type="text"
                            name='toDo'
                            // double binding
                            value = {toDo}
                            onChange={(e) => setToDo(e.target.value)}
                        />
                        <input 
                        type="hidden"
                        name='statuss'
                        value={statuss}
                        />
                        

                        <button>button</button>
                    </div>
                </form>
    </div>
  )
}

export default ToDoForm