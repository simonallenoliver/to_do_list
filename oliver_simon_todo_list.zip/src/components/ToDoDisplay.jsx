import React, { useState } from 'react'

const ToDoDisplay = (props) => {
    const { toDo } = props
    const [statuss, setStatus] = useState(false);
    let decoration = "none"
    if(statuss == true){decoration = "line-through"}

    return (
        <div className='boxDisplay'>
            <h1>My ToDo List</h1>
            {
                toDo.map((randomParam, index) => (
                    
                    <div className='listofstuff' key={index}>
                        <div style={{textDecoration: decoration}}>{randomParam.toDo} </div>
                        <div className='checkboxx'><input 
                        type='checkbox'
                        name = 'statuss'
                        checked = {statuss}
                        onChange={e =>setStatus(e.target.checked)}
                        /></div>
                    </div>

                ))
            }
        </div>
    )
}

export default ToDoDisplay